#pragma once

#include <omp.h>
#include "mpi.h"
#include <cstdlib>
#include <math.h>
#include <ctime>
#include <iostream>
#include <fstream>
#include <string>
#include <Windows.h>
#include <vector>
#include <conio.h>
#include "matrix_csr.h"
#include "mvector.h"

#define N_TH 1 // ���������� ��������� ��� OpenMP

int count_displs(int *sizes, int ran);
Vector sopr_grad_meth(int size, int rank, std::vector<double> paelem, std::vector<double> padiag, std::vector<int> pai, std::vector<int> paj, int pN, std::vector<double> pb_col);
//Vector sopr_grad_meth(std::vector<double> paelem, std::vector<double> padiag, std::vector<int> pai, std::vector<int> paj, int pN, std::vector<double> pb_col);
