#include "matrix_csr.h"

///////////////////////////////////////////////////////////////////////////////////////
Matrix_csr::Matrix_csr() //����������� �� ���������
{ 
	N = 1;
}

Matrix_csr::Matrix_csr(int pN)
{
	N = pN;	
	len = pN;
	for (int i = 0; i < N + 1; i++)
		aI.push_back(0);
	for (int i = 0; i < N; i++)
		adiag.push_back(0);
}

Matrix_csr::Matrix_csr(int pN, int pLen)
{
	N = pN;
	len = pLen;
	for (int i = 0; i < N + 1; i++)
		aI.push_back(0);
	for (int i = 0; i < N; i++)
		adiag.push_back(0);
}

Matrix_csr::Matrix_csr(std::vector<double> paelem, std::vector<double> padiag, std::vector<int> pai, std::vector<int> paj, int pN, int pN_elem) // constr with parametrs
{
	N = pN;
	N_elem = pN_elem;
	len = pN;

	adiag.insert(aelem.begin(), padiag.begin(), padiag.end());
	aelem.insert(aelem.begin(), paelem.begin(), paelem.end());
	aJ.insert(aJ.begin(), paj.begin(), paj.end());
	aI.insert(aI.begin(), pai.begin(), pai.end());
}

Matrix_csr::Matrix_csr(const Matrix_csr & a) // copy constr
{
	N = a.N;
	N_elem = a.N_elem;
	len = a.len;

	aelem.insert(aelem.begin(), a.aelem.begin(), a.aelem.end());
	adiag.insert(adiag.begin(), a.adiag.begin(), a.adiag.end());
	aJ.insert(aJ.begin(), a.aJ.begin(), a.aJ.end());
	aI.insert(aI.begin(), a.aI.begin(), a.aI.end());
}

Matrix_csr::~Matrix_csr() //����������
{

}
///////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
Matrix_csr & Matrix_csr::operator =(const Matrix_csr & b)//���������� ������������
{
	if (this == &b) { return (*this); }
	N = b.N;
	N_elem = b.N_elem;
	len = b.len;

	aelem.clear();
	adiag.clear();
	aJ.clear();
	aI.clear();

	aelem.insert(aelem.begin(), b.aelem.begin(), b.aelem.end());
	adiag.insert(adiag.begin(), b.adiag.begin(), b.adiag.end());
	aJ.insert(aJ.begin(), b.aJ.begin(), b.aJ.end());
	aI.insert(aI.begin(), b.aI.begin(), b.aI.end());
	
	return(*this);
}

std::ostream & operator <<(std::ostream & p_Out, Matrix_csr & p_M) // ����� ����������� �� �����
{
	int i, j;
	for (i = 0; i < p_M.aI.size()-1; i++)
	{
		for (j = 0; j < p_M.aI.size()-1; j++)
		{
			printf("%f  ", p_M.get_element(i, j));
		}
		printf("\n");
	}
	printf("\n");
	return p_Out;
}
///////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////
double Matrix_csr::get_element(int i, int j)
{
	double AA = 0;
	int N1, N2;
	int k;
	//if (i < adiag.size() && j < aelem.size())
	//{
		if (i == j)
		{
			AA = adiag[i];
		}
		else
		{
			N1 = aI[i];
			N2 = aI[i + 1];
			for (k = N1; k < N2; k++)
			{
				if (k < aJ.size())
					if (aJ[k] == j)
					{
						AA = aelem[k];
						break;
					}
			}
		}
	//}

	return AA;
}
//////////////////////////////////////////////////////////////////////////////////////

int Matrix_csr::getsizeN()
{
	return adiag.size();
}

int Matrix_csr::getsizeN_elem()
{
	return aelem.size();
}

int Matrix_csr::getLen()
{
	return aelem.size();
}

Matrix_csr Matrix_csr::operator+(Matrix_csr & b)//�� ���������
{

	return Matrix_csr();
}

Matrix_csr Matrix_csr::operator-(Matrix_csr & b)//�� ���������
{

	return Matrix_csr();
}

Matrix_csr Matrix_csr::operator-() //�� ���������
{

	return Matrix_csr();
}

Matrix_csr Matrix_csr::operator*(const double & c)//�� ���������
{

	return Matrix_csr();
}

Vector Matrix_csr::operator*(Vector & p_b)
{
	omp_set_num_threads(N_TH);

	Vector res(p_b.content.size());
	int i, j;

	if (p_b.content.size() != adiag.size())
	{
		std::cout << "\n MULT MATRVECT SIZES NOT SUITABLE!\n";
		std::cout.flush();
		return res;
	}

#pragma omp parallel  shared(p_b)
	{
	#pragma omp for schedule(guided,1)
		for (i = 0; i < p_b.content.size(); i++)
		{
			res.set_el(i, p_b[i] * adiag[i]);
		}
	}

#pragma omp parallel private(j) shared(p_b)
	{
#pragma omp for schedule(guided,1)
		for (i = 0; i < p_b.content.size(); i++)
		{
			if(aI[i] < aelem.size())
			for (j = aI[i]; j < aI[i + 1]; j++)
			{
				res.set_el(i, res[i] + p_b[aJ[j]] * aelem[j]);
			}
		}
	}

	return res;
}
/////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////