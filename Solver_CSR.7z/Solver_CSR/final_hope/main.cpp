#include "global.h"

int read_data_file(std::vector<double>& padiag, std::vector<double>& paelem, 
	std::vector<int> &pai, std::vector<int>& paj, std::vector<double> &b_st)
{
	int size;
	std::string str;
	std::string buf;
	std::ifstream  file1("EquationsSystemCSR_1.txt", std::ios_base::in);
	if (file1.is_open())
	{
//////////////////////////////////////////////////////
		str.clear();
		getline(file1, str);
		size = atoi(str.c_str());
		//std::cout << "\nSIZE1: " << size << "\n";

		str.clear();
		buf.clear();
		getline(file1, str);
		for (int i = 0; i < str.size(); i++)
		{
			if (str.at(i) == ' ' || str.at(i) == '\n')
			{
				padiag.push_back(atof(buf.c_str()));
				buf.clear();
			}
			else
			{
				buf+=str[i];
			}
		}
		if(!buf.empty())
			padiag.push_back(atof(buf.c_str()));
//////////////////////////////////////////////////
		str.clear();
		getline(file1, str);
		size = atoi(str.c_str());
		//std::cout << "\nSIZE2: " << size << "\n";

		str.clear();
		buf.clear();
		getline(file1, str);
		for (int i = 0; i < str.size(); i++)
		{
			if (str.at(i) == ' ' || str.at(i) == '\n')
			{
				pai.push_back(atoi(buf.c_str()));
				buf.clear();
			}
			else
			{
				buf += str[i];
			}
		}
		if (!buf.empty())
			pai.push_back(atoi(buf.c_str()));
/////////////////////////////////////////////////////
		str.clear();
		getline(file1, str);
		size = atoi(str.c_str());
		//std::cout << "\nSIZE3: " << size << "\n";

		str.clear();
		buf.clear();
		getline(file1, str);
		for (int i = 0; i < str.size(); i++)
		{
			if (str.at(i) == ' ' || str.at(i) == '\n')
			{
				paj.push_back(atoi(buf.c_str()));
				buf.clear();
			}
			else
			{
				buf += str[i];
			}
		}
		if (!buf.empty())
			paj.push_back(atoi(buf.c_str()));
///////////////////////////////////////////////
		str.clear();
		getline(file1, str);
		size = atoi(str.c_str());
		//std::cout << "\nSIZE4: " << size << "\n";

		str.clear();
		buf.clear();
		getline(file1, str);
		for (int i = 0; i < str.size(); i++)
		{
			if (str.at(i) == ' ' || str.at(i) == '\n')
			{
				paelem.push_back(atof(buf.c_str()));
				buf.clear();
			}
			else
			{
				buf += str[i];
			}
		}
		if (!buf.empty())
			paelem.push_back(atof(buf.c_str()));
/////////////////////////////////////////////////////
		str.clear();
		getline(file1, str);
		size = atoi(str.c_str());
		//std::cout << "\nSIZE5: " << size << "\n";

		str.clear();
		buf.clear();
		getline(file1, str);
		for (int i = 0; i < str.size(); i++)
		{
			if (str.at(i) == ' ' || str.at(i) == '\n')
			{
				b_st.push_back(atof(buf.c_str()));
				buf.clear();
			}
			else
			{
				buf += str[i];
			}
		}
		if (!buf.empty())
			b_st.push_back(atof(buf.c_str()));
		
	}
	else
	{
		std::cout << "\nFILE NOT OK!\n";
	}

	file1.close();

	return 0;
}

int main(int argc, char** argv)
{
	int rank, size;
	int N = 4;

	double start_time, fin_time; // TIME

	std::vector<double> padiag;
	std::vector<double> paelem;
	std::vector<int> paj;
	std::vector<int> pai;
	std::vector<double> b_st;

	read_data_file(padiag, paelem, pai, paj, b_st);

	//padiag.push_back(2);
	//padiag.push_back(3);
	//padiag.push_back(5);
	//padiag.push_back(1);
	//paelem.push_back(1);
	//paelem.push_back(1);
	//paj.push_back(1);
	//paj.push_back(0);
	//pai.push_back(0);
	//pai.push_back(1);
	//pai.push_back(2);
	//pai.push_back(2);
	//pai.push_back(3);
	//b_st.push_back(3);
	//b_st.push_back(4);
	//b_st.push_back(2);
	//b_st.push_back(1);

	//std::cout << "\nADIAG: ";
	//for (int i = 0; i < padiag.size(); i++)
	//{
	//	std::cout << padiag.at(i) << " ";
	//}
	//std::cout << "\n";
	//std::cout << "\nIPTR: ";
	//for (int i = 0; i < pai.size(); i++)
	//{
	//	std::cout << pai.at(i) << " ";
	//}
	//std::cout << "\n";
	//std::cout << "\nJPTR: ";
	//for (int i = 0; i < paj.size(); i++)
	//{
	//	std::cout << paj.at(i) << " ";
	//}
	//std::cout << "\n";
	//std::cout << "\nAELEM: ";
	//for (int i = 0; i < paelem.size(); i++)
	//{
	//	std::cout << paelem.at(i) << " ";
	//}
	//std::cout << "\n";
	//std::cout << "\nB: ";
	//for (int i = 0; i < b_st.size(); i++)
	//{
	//	std::cout << b_st.at(i) << " ";
	//}
	//std::cout << "\n";

	MPI_Init(&argc, &argv); // START PARALL
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	MPI_Barrier(MPI_COMM_WORLD);
	start_time = MPI_Wtime(); // TIME OF START

	Vector Vresult(N);
	Vresult = sopr_grad_meth(size, rank, paelem, padiag, pai, paj, b_st.size(), b_st);

	MPI_Barrier(MPI_COMM_WORLD);
	fin_time = MPI_Wtime() - start_time;
	if (rank == 0)
	{
		std::cout << "\nRESULT TIME = " << fin_time << "\n";
		//std::cout << "\nRESULT= " << Vresult << "\n";
	}

	MPI_Finalize(); // FINISH PARALL

	return 0;
}